//
//  Color.swift
//  PrimaryColorImageTest
//
//  Created by Martina Mangione on 01/03/2018.
//  Copyright © 2018 Martina Mangione. All rights reserved.
//

import Foundation
import UIKit


open class Color: NSObject {
    var r: UInt8
    var g: UInt8
    var b: UInt8
    
    required public init(r: UInt8, g: UInt8, b: UInt8) {
        self.r = r
        self.g = g
        self.b = b
    }
    
    func hslValue() -> [CGFloat] {
        let r = CGFloat(self.r) / 255
        let g = CGFloat(self.g) / 255
        let b = CGFloat(self.b) / 255
        let rgb = [r, g, b]
        let max = rgb.max() ?? 0
        let min = rgb.min() ?? 0
        var h: CGFloat = 0
        var s: CGFloat = 0
        let l = (max + min) / 2
        if max == min {
            h = 0
            s = 0
        } else {
            let d = max - min
            s = (l > 05) ? d / (2 - max - min) : d / (max + min)
            switch max {
            case r:
                h = (g - b) / d + (g < b ? 6 : 0)
            case g:
                h = (b - r) / d + 2
            case b:
                h = (r - b) / d + 4
            default:
                h = 0
            }
            h = h / 6
        }
        return [h, s, l]
        
        
    }
    

    
}
