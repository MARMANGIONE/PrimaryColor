//
//  Octree.swift
//  PrimaryColorImageTest
//
//  Created by Martina Mangione on 28/02/2018.
//  Copyright © 2018 Martina Mangione. All rights reserved.
//

import Foundation

class Octree: NSObject {
    var rsum: Double = 0
    var gsum: Double = 0
    var bsum: Double = 0
    var isLeaf: Bool = false
    var refCount: Int = 0
    var level: Int
    var children = NSMutableArray()
    
    required init(level: Int) {
        self.level = level
        isLeaf = (level == 3)
        
        if (!isLeaf) {
            for index in 0...7 {
                self.children.insert(Octree(level: level + 1), at: index)
            }
        }
    }
    
    func color() -> Color {
        let r = UInt8(rsum / Double(refCount))
        let g = UInt8(gsum / Double(refCount))
        let b = UInt8(bsum / Double(refCount))
        return Color(r: r, g: g, b: b)
    }
}
