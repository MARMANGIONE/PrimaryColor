//
//  ColorQuantizer.swift
//  PrimaryColorImageTest
//
//  Created by Martina Mangione on 28/02/2018.
//  Copyright © 2018 Martina Mangione. All rights reserved.
//

import Foundation
import CoreGraphics
import UIKit


class ColorQuantizer: NSObject {
    var octree: Octree
    let hexasForBitLevel = [0x80, 0x40, 0x20, 0x10]
    
    required override init() {
        self.octree = Octree(level: 0)
    }
    
    // Returns RGB-bit for level, level can be 0-3
    fileprivate func bitForLevel(_ level: Int, color: Color) -> Int {
        let hexa = UInt8(self.hexasForBitLevel[level])
        let bitsToShift = UInt8(7 - level)
        let a = (color.r&hexa) >> bitsToShift
        let redCondition =  (a << 2)
        let greenCondition = (((color.g&hexa) >> bitsToShift) << 1)
        let blueCondition = ((color.b&hexa) >> bitsToShift)
        return Int(redCondition | greenCondition | blueCondition)
    }
    
    // Add color to a tree
    func addColor(_ tree: Octree, color: Color) {
        if (tree.isLeaf) {
            tree.rsum += Double(color.r)
            tree.gsum += Double(color.g)
            tree.bsum += Double(color.b)
            tree.refCount += 1
        } else {
            let deeperLevel = tree.level + 1
            let levelBit = self.bitForLevel(deeperLevel, color: color)
            
            self.addColor(tree.children[levelBit] as! Octree, color: color)
        }
    }
    
    func getPalette(_ tree: Octree, colors: NSMutableArray) {
        if (tree.isLeaf && tree.refCount > 0) {
            colors.add(tree.color())
        } else if (!tree.isLeaf) {
            for index in 0...7 {
                getPalette(tree.children[index] as! Octree, colors: colors)
            }
        }
    }
}

