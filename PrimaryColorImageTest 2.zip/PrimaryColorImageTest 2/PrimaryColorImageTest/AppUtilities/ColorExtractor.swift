//
//  ColorExtractor.swift
//  PrimaryColorImageTest
//
//  Created by Martina Mangione on 28/02/2018.
//  Copyright © 2018 Martina Mangione. All rights reserved.
//

import Foundation
import UIKit

class ColorExtractor: NSObject {
    
    
    func extractCustomColorsWithImageData(_ data: CFData?) -> [Color] {
        let buf = CFDataGetBytePtr(data)
        let l = CFDataGetLength(data)
        let vibrant = ColorQuery(targetLuma: 0.5, minLuma: 0.3, maxLuma: 0.7, targetSaturation: 1, minSaturation: 0.35, maxSaturation: 1)
        let lightVibrant = ColorQuery(targetLuma: 0.74, minLuma: 0.55, maxLuma: 1, targetSaturation: 1, minSaturation: 0.35, maxSaturation: 1)
        let darkVibrant = ColorQuery(targetLuma: 0.26, minLuma: 0, maxLuma: 0.45, targetSaturation: 1, minSaturation: 0.35, maxSaturation: 1)
        let muted = ColorQuery(targetLuma: 0.5, minLuma: 0.3, maxLuma: 0.7, targetSaturation: 0.3, minSaturation: 0, maxSaturation: 0.4)
        let lightMuted = ColorQuery(targetLuma: 0.74, minLuma: 0.55, maxLuma: 1, targetSaturation: 0.3, minSaturation: 0, maxSaturation: 0.4)
        let darkMuted = ColorQuery(targetLuma: 0.26, minLuma: 0, maxLuma: 0.45, targetSaturation: 0.3, minSaturation: 0, maxSaturation: 0.4)
        var colorQueries = [ColorQuery]()
        colorQueries.append(vibrant)
//        colorQueries.append(lightVibrant)
//        colorQueries.append(darkVibrant)
//        colorQueries.append(muted)
//        colorQueries.append(lightMuted)
//        colorQueries.append(darkMuted)
        // Quantize colors
        let quantizer = ColorQuantizer()
        
        var i = 0
        while i < l {
            let red = buf?[i]
            let green = buf?[i+1]
            let blue = buf?[i+2]
            quantizer.addColor(quantizer.octree, color: Color(r: red!, g: green!, b: blue!))
            
            i += 4
        }
        
        // Get quantized palette
        let palette = NSMutableArray()
        quantizer.getPalette(quantizer.octree, colors: palette)
        var colorArray = [Color]()
        for color: Color in palette as NSArray as! [Color] {
            for colorQuery in colorQueries {
                let colorMatched = matchColorToQuery(color, colorQuery: colorQuery)
                if (colorMatched != nil) {
                    colorArray.append(colorMatched!)
                }
            }
        }
        return colorArray
    }
    
    func matchColorToQuery(_ color: Color, colorQuery: ColorQuery) -> Color? {
        var targetColor: Color? = colorQuery.foundColor
        var hsl = color.hslValue()
        let s = hsl[1]
        let l = hsl[2]
        if (colorQuery.minLuma <= l && colorQuery.maxLuma >= l && colorQuery.minSaturation <= s && colorQuery.maxSaturation >= s) {
            if (targetColor != nil) {
                var targetHsl = targetColor?.hslValue()
                if (abs(l - colorQuery.targetLuma) < abs(targetHsl![2] - colorQuery.targetLuma)) {
                    targetColor = color
                }
            } else {
                targetColor = color
            }
        }
        colorQuery.foundColor = targetColor
        return targetColor
    }
}
