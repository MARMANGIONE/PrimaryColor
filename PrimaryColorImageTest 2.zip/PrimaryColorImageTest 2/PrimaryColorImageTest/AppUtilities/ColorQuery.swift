//
//  ColorQuery.swift
//  PrimaryColorImageTest
//
//  Created by Martina Mangione on 28/02/2018.
//  Copyright © 2018 Martina Mangione. All rights reserved.
//

import Foundation
import UIKit


open class ColorQuery: NSObject {
    open var targetLuma: CGFloat
    open var minLuma: CGFloat
    open var maxLuma: CGFloat
    open var targetSaturation: CGFloat
    open var minSaturation: CGFloat
    open var maxSaturation: CGFloat
    open var foundColor: Color?
    
    public init(targetLuma: CGFloat, minLuma: CGFloat, maxLuma: CGFloat, targetSaturation: CGFloat, minSaturation: CGFloat, maxSaturation: CGFloat) {
        self.targetLuma = targetLuma
        self.minLuma = minLuma
        self.maxLuma = maxLuma
        self.targetSaturation = targetSaturation
        self.minSaturation = minSaturation
        self.maxSaturation = maxSaturation
    }
}
